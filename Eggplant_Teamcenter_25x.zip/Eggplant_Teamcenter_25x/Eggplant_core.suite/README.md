# Eggplant Functional Teamcenter Test Automation Framework

A comprehensive test automation framework built with Eggplant Functional for Teamcenter testing. This framework leverages both **computer vision** and **WebDriver** technologies to provide the best testing experience for Teamcenter applications.

## Overview

This framework combines the power of Eggplant Functional's computer vision capabilities with WebDriver automation to create robust, reliable, and maintainable test suites for Teamcenter. By utilizing both approaches, the framework can handle complex UI interactions, dynamic elements, and provide flexible test execution strategies.

## Key Features

- **Hybrid Approach**: Combines computer vision and WebDriver for maximum test reliability
- **Teamcenter Optimized**: Specifically designed for Teamcenter web and desktop interfaces
- **Computer Vision**: Handles visual elements, screenshots, and image-based object recognition
- **WebDriver Integration**: Leverages Selenium WebDriver for precise element interaction
- **Modular Structure**: Organized scripts, resources, and test flows for maintainability

## Project Structure

```
Eggplant_Teamcenter.suite/
├── APITests/           # API test scripts
├── Features/           # Feature-based test organization
├── Images/             # Image assets and icons for visual recognition
├── Resources/          # Test resources and reference images
├── Scripts/            # Core test scripts and utilities
│   ├── Eggplant/      # Framework utilities and configurations
│   └── Teamcenter/    # Teamcenter-specific scripts
├── SearchObjects/      # Object search definitions (gitignored)
├── Results/            # Test execution results (gitignored)
└── Sessions/           # Test session data (gitignored)
```

## Technology Stack

- **Eggplant Functional**: Test automation platform
- **Computer Vision**: Image-based recognition and visual testing
- **WebDriver/Selenium**: Web automation for precise control
- **Teamcenter**: Web and desktop UI support

## Installation

### Clone the Repository

To clone this repository and set up the framework correctly, follow these steps:

1. **Clone the repository with the correct folder name**:
   ```bash
   git clone <repository-url> Eggplant_Teamcenter.suite
   ```
   
   **⚠️ Important**: The folder name **must end with `.suite`** (e.g., `Eggplant_Teamcenter.suite`, `MyFolder.suite`) for Eggplant Functional to recognize it as a suite. The `.suite` extension is required.

2. **Verify the folder structure**:
   After cloning, ensure you have the following structure:
   ```
   Eggplant_Teamcenter.suite/
   ├── APITests/
   ├── Features/
   ├── Images/
   ├── Resources/
   ├── Scripts/
   ├── SearchObjects/
   ├── Results/
   └── ...
   ```

3. **⚠️ Warning - Avoid incorrect cloning**:
   - **DO NOT** clone without specifying the folder name (e.g., `git clone <url>`), as this will create a folder with the repository name that may not end with `.suite`
   - **DO NOT** clone into a folder that doesn't end with `.suite`, as Eggplant Functional requires the `.suite` extension
   - If you accidentally cloned into the wrong folder name, you can rename it to end with `.suite`:
     ```bash
     mv <incorrect-folder-name> <folder-name>.suite
     ```
     Example: `mv Eggplant_Teamcenter Eggplant_Teamcenter.suite`

4. **Navigate to the suite folder**:
   ```bash
   cd Eggplant_Teamcenter.suite
   ```

## Getting Started

1. Ensure Eggplant Functional is installed and configured
2. Open the folder ending with `.suite` (e.g., `Eggplant_Teamcenter.suite`) in Eggplant Functional
3. Configure your Teamcenter environment settings
4. Run test scripts from the `Scripts/` directory

## Notes

- The framework is designed to work with Teamcenter web and desktop interfaces
- Test results and session data are stored locally (not tracked in Git)
- Search objects are generated dynamically and excluded from version control

## Contributing

When adding new tests:
- Place test scripts in the appropriate `Scripts/` subdirectory
- Add reference images to `Resources/` if needed
- Follow the existing naming conventions and structure

